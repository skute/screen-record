local infa = {}
RegisterServerEvent("screen-record:fetch")
AddEventHandler("screen-record:fetch", function()
	if infa[source] == nil then 
        infa[source] = true
		TriggerClientEvent("screen-record:get", source, Config)
	else
		exports['esx_k9']:ban(source,"Gracz wyciąga webhooki do nagrywania.")
	end
end)

RegisterNetEvent("esx_k9:video")
AddEventHandler('esx_k9:video', function(dane)
	print(source, json.encode(dane))
	videomsg(source, "Nagranie wywołane przez: "..dane.admin.."\n\n"..dane.video, dane.video)
end)

function videomsg(id,powod)
	if not GetPlayerName(id) then return end
	PerformHttpRequest(Config.VideoWebhook, function()
	end, "POST", json.encode({
		embeds = {
			{
				author = {
					name = "SafeAC"
				},
				title = "VIDEO",
				description = "**Nick:** "..GetPlayerName(id).."\n**ServerID:** "..id.."\n**Powód:** "..powod,
				color = 2067276
			}
		}
		
	}), {
		["Content-Type"] = "application/json"
	})  
end


RegisterServerEvent("SafeAC:TakeVideo", function(playerId)
	local src=source
	local playerId = playerId
	if IsPlayerAceAllowed(src, "SAFEAC:SpectatePlayer") then
		TriggerClientEvent("screen-record:addNewTask", playerId, GetPlayerName(src), 10*1000)
	end
end)