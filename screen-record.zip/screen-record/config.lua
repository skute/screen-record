Config = {}
Config.ScreenshotWebhook = ""
Config.VideoWebhook = ""
