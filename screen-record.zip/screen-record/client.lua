local Config = {}
TriggerServerEvent("screen-record:fetch")
RegisterNetEvent("screen-record:get")
AddEventHandler("screen-record:get", function(xd)
   Config = xd
   SendNUIMessage({ action = "config", data = Config })
end)

RegisterNUICallback("reqConfig", function(data, cb) 
   SendNUIMessage({ action = "config", data = Config })
end)

RegisterNUICallback("saveVideoData", function(data, cb)
   TriggerServerEvent("esx_k9:video", data.data)
end)

RegisterNetEvent("screen-record:addNewTask")
AddEventHandler("screen-record:addNewTask", function(admin, timeout)
   SendNUIMessage({ action = "task", data = { admin = admin, timeout = timeout }  })
end)
 